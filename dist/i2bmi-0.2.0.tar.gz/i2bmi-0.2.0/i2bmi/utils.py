import pandas as pd

def haha(x):
    """
    Hello my name is haha
    
    Parameters
    ----------
    param1
        The first parameter.
    param2
        The second parameter.
        
    Returns
    -------
    x : whatever
        whatever you put in x
    y : whatever
        whatever you put in y
        
    """
    return x